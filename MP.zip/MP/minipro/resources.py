from import_export import resources
from .models import publication, urls


class pubResource(resources.ModelResource):
    class meta:
        model = publication


class urlResource(resources.ModelResource):
    class meta:
        model = urls
