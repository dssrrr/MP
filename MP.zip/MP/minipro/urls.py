"""MajorProject URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path

from . import views
from django.contrib.staticfiles.urls import staticfiles_urlpatterns


urlpatterns = [

    #path('', views.home, name="home"),
    #path('accounts/', include('django.contrib.auth.urls')),
    path('', views.login, name="login"),
    path('Ahome', views.homeAdm, name="home_a"),
    path('Ahome/update', views.updateP, name="update"),
    path("Ahome/update/del fac", views.del_Fac),
    path("Ahome/update/add author id", views.auth_id),
    path("Fhome", views.searchPub, name="home_f"),
    path("Fhome/MyProfile", views.myProfile, name="profile"),
    path('Fhome/MyProfile/Add_pub', views.addP),
    path("Fhome/Password", views.changePwd, name="pwd"),
    path("Fhome/MyProfile/Edit_pub", views.editP, name="editP"),
    path("Fhome/Summary", views.summaryF, name="summF"),
    #path("Fhome/Research Profiles", views.frpForm, name="facrpForm"),

    path('Shome', views.searchStu, name="home_s"),
    path("Shome/RP Form", views.rpForm, name="rpForm"),
    path('Publications', views.searchAdm, name="pub_a"),
    path('Summary', views.rpForm_adm, name="summary_adm"),
]
urlpatterns += staticfiles_urlpatterns()
