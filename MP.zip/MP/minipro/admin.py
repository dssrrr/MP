from django.contrib import admin
from import_export.admin import ImportExportModelAdmin
from minipro.models import login_db, publication, urls, author_ids

admin.site.register(login_db)
admin.site.register(publication)
admin.site.register(urls)
admin.site.register(author_ids)


class pubAdmin(ImportExportModelAdmin):
    list_display = ('fid', 'fname', 'title', 'pub_type',
                    'publisher_name', 'published_yr', 'issn_no')


class urlAdmin(ImportExportModelAdmin):
    list_display = ('fid', 'url')
