from django.forms.widgets import TextInput, Textarea
from django.forms import widgets
import django_filters
from .models import publication
from django_filters import CharFilter


class pubFilter(django_filters.FilterSet):
    faculty_name = CharFilter(
        field_name="faculty_name", lookup_expr='icontains')
    title = CharFilter(field_name="title", lookup_expr='icontains')
    publisher_name = CharFilter(
        field_name="publisher_name", lookup_expr='icontains')
    publication_type = CharFilter(
        field_name="publication_type", lookup_expr='iexact')

    class Meta:
        model = publication
        fields = ['faculty_id', 'faculty_name', 'published_yr',
                  'publication_type',  'title', 'publisher_name']
