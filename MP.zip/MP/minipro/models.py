from django.db import models


class login_db(models.Model):
    username = models.CharField(max_length=15, primary_key=True)
    password = models.CharField(max_length=8)

    def __str__(self):
        return str(self.username)


class author_ids(models.Model):
    faculty_id = models.ForeignKey(login_db, on_delete=models.CASCADE)
    author_id = models.CharField(max_length=25, null=True, unique=True)


class publication(models.Model):
    faculty_id = models.ForeignKey(login_db, on_delete=models.CASCADE)
    faculty_name = models.CharField(max_length=50)
    title = models.CharField(max_length=100)
    authors = models.CharField(max_length=200, default="-")
    publication_type = models.CharField(max_length=30, default="-")
    name = models.CharField(max_length=150, default="-")
    publisher_name = models.CharField(max_length=100, default="-")
    published_yr = models.CharField(max_length=4, default="-")
    issn_no = models.CharField(max_length=15, default="--")
    impact_factor = models.FloatField(default=0)
    h_index = models.IntegerField(default=0)
    citations = models.IntegerField(default=0)
    Scopus = models.IntegerField(default=0)
    WebOfScience = models.IntegerField(default=0)


class urls(models.Model):
    faculty_id = models.ForeignKey(login_db, on_delete=models.CASCADE)
    url = models.URLField(max_length=200)
