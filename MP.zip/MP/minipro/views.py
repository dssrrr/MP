from audioop import reverse
from time import sleep
import time
from typing import Reversible
from .filters import pubFilter
from django.http import HttpResponse
from django.shortcuts import render, redirect
# Database
from minipro.models import login_db, publication, urls, author_ids
# Excel to db
from .resources import pubResource, urlResource
from tablib import Dataset
# Alert Messages
from django.contrib import messages
# Web Scraping
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import NoSuchElementException, StaleElementReferenceException, TimeoutException
from selenium.webdriver.support.select import Select
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
import requests
# search
from minipro.filters import pubFilter

# export to excel
import csv
from django.conf import settings
from django.core.files.storage import FileSystemStorage

from django.db.models import Count

i = 0


def login(request):
    uname = request.POST.get('uname')
    pwd = request.POST.get('pwd')
    check = login_db.objects.filter(username=uname, password=pwd).values()
    if len(check) == 1:
        request.session['id'] = uname
        if uname[0] == 'F':
            return redirect(searchPub)

        elif uname[0] == 'A':
            return redirect(homeAdm)
        else:
            return redirect(searchStu)
    return render(request, "login.html")


def homeAdm(request):
    id = request.session.get('id')
    context = {'id': id}
    op1 = request.POST.get('sb1')
    op2 = request.POST.get('sb2')
    op3 = request.POST.get('sb3')
    if request.method == "POST":
        if op3 != None:
            global i
            context = {'id': id}
            op = request.POST.get('sb3')
            if request.method == "POST" and op != None:
                url_res = urlResource
                dataset = Dataset()
                if request.FILES['urlslist']:
                    nurl = request.FILES['urlslist']
                    if not nurl.name.endswith('xlsx'):
                        print("ERROR!!")
                        messages.info(request, 'Wrong Format')
                        return render(request, 'home_a.html', context)
                    imp_data = dataset.load(nurl.read(), format='xlsx')
                    up_cnt = 0
                    notup_cnt = 0
                    for data in imp_data:
                        c = login_db.objects.filter(username=data[1]).values()
                        if len(c) == 0:
                            messages.info(request, 'Enter Valid Faculty ID!!')
                        else:

                            if urls.objects.filter(faculty_id_id=data[1], url=data[2]).values().count() == 0:
                                v = urls(data[0], data[1], data[2])
                                i += 1
                                v.save()
                                up_cnt += 1

                            else:
                                notup_cnt += 1
                            options = webdriver.ChromeOptions()
                            options.add_experimental_option(
                                'excludeSwitches', ['enable-logging'])
                            driver = webdriver.Chrome(chrome_options=options)
                            cnt = 0
                            ncnt = 0
                            url = str(data[2])
                            faculty_id = str(data[1])
                            driver.get(url)

                            b = driver.find_element(By.ID, "gsc_bpf_more")
                            driver.execute_script(
                                "arguments[0].scrollIntoView(true);", b)
                            b.click()
                            sleep(10)
                            j = 0
                            while j < 6:
                                j += 1
                                # print("More")
                                driver.execute_script(
                                    "arguments[0].scrollIntoView(true);", b)
                                b.click()

                            faculty_name = driver.title[:-18]
                            pub_titles = driver.find_elements(
                                By.CLASS_NAME, "gsc_a_tr")
                            # TO OPEN SCOPUS WEBSITE
                            '''
                            driver4 = webdriver.Chrome(
                                chrome_options=options)
                            #driver4.get('https://www.scopus.com/sources.uri')
                            #driver4.find_element(By.CLASS_NAME,'button_776c1f container_776c1f size-l_776c1f icon-colored_776c1f oneIcon_776c1f GlobalHeader-module__1Ymcu')
                            driver4.get(
                                'https://id.elsevier.com/as/authorization.oauth2?platSite=SC%2Fscopus&ui_locales=en-US&scope=openid+profile+email+els_auth_info+els_analytics_info+urn%3Acom%3Aelsevier%3Aidp%3Apolicy%3Aproduct%3Aindv_identity&els_policy=idp_policy_indv_identity_plus&response_type=code&redirect_uri=https%3A%2F%2Fwww.scopus.com%2Fauthredirect.uri%3FtxGid%3Dcb06bc34b05b06755733b2fc4b0f32d0&state=userLogin%7CtxId%3D18D80740F186F5FA9FD5323B8C4BE0C4.i-04a4f73bb36ba75bc%3A9&authType=SINGLE_SIGN_IN&prompt=login&client_id=SCOPUS')
                            sleep(5)
                            email = driver4.find_element(
                                By.ID, "bdd-email")
                            email.clear()
                            email.send_keys("shivanid11@gnits.ac.in")
                            sleep(2)
                            driver4.find_element(
                                By.ID, "bdd-elsPrimaryBtn").click()
                            pwd = driver4.find_element(
                                By.ID, "bdd-password")
                            pwd.clear()
                            pwd.send_keys("@D.s.r123")
                            sleep(2)

                            driver4.find_element(
                                By.ID, "bdd-elsPrimaryBtn").click()

                            opt_val = "TITLE"
                            scopus = 0
                            optns = driver4.find_element(
                                By.XPATH, "//select[option[@value='%s']]" % opt_val)
                            select = Select(optns)
                            select.select_by_value(opt_val)
                            '''
                            for each_tit in pub_titles:
                                title_link = each_tit.find_element(
                                    By.CLASS_NAME, "gsc_a_at")
                                title = title_link.text
                                # SEARCH IN SCOPUS
                                '''
                                inp_box = driver4.find_element(
                                    By.CLASS_NAME, "flex-grow-1")
                                inp_box.clear()
                                inp_box.send_keys(title)
                                submit_btn = driver4.find_element(
                                    By.CLASS_NAME, "DocumentSearchForm-module__7qtE8")
                                submit_btn.submit()
                                sleep(5)
                                try:
                                    tit = driver4.find_element(
                                        By.CLASS_NAME, "ddmDocTitle").text
                                    print(tit)
                                    if tit.lower() == title.lower():
                                        scopus = 1
                                except:
                                    scopus = 0
                                print(title, "-", scopus)
                                driver4.back()
                                '''
                                published_yr = "-"
                                published_yr = each_tit.find_element(
                                    By.CLASS_NAME, "gsc_a_y").text
                                a = each_tit.find_element(
                                    By.CLASS_NAME, "gsc_a_c")
                                val = a.find_element(By.TAG_NAME, 'a')
                                if val.text != '':
                                    citations = int(val.text)
                                else:
                                    citations = 0
                                try:
                                    h_row = driver.find_elements(
                                        By.CLASS_NAME, "gsc_rsb_std")
                                    for x in range(3):
                                        h_index = h_row[x].text
                                except:
                                    h_index = 0
                                title_link.click()
                                details = driver.find_elements(
                                    By.CLASS_NAME, "gs_scl")
                                val_fields = ["Book", "Journal", "Conference"]
                                publisher_name = "-"
                                publication_type = "-"
                                name = "-"
                                for each in details:
                                    field = each.find_element(
                                        By.CLASS_NAME, "gsc_oci_field").text
                                    value = each.find_element(
                                        By.CLASS_NAME, "gsc_oci_value").text
                                    if field == "Authors":
                                        authors = value
                                        print(authors)
                                    if field == "Publisher":
                                        publisher_name = value
                                    if field in val_fields:
                                        publication_type = field.upper()
                                        name = value

                                webOfScience = 0
                                impact_factor = 0
                                issn = "--"
                                scopus = 0
                                # IMPACT FACTOR - IEEE
                                if (publisher_name == "KICS" or publisher_name == "IEEE"):
                                    # print("each:", driver.current_url)
                                    try:
                                        next_page = driver.find_element(
                                            By.CLASS_NAME, "gsc_oci_title_link").get_attribute("href")
                                        driver3 = webdriver.Chrome(
                                            options=options)
                                    except StaleElementReferenceException:
                                        print("NoSuchElementException")
                                    except NoSuchElementException:
                                        print("NoSuchElementException")
                                    driver3.get(next_page)
                                    src = driver3.page_source
                                    e_issn = "Electronic ISSN"
                                    e_isbn = "Electronic ISBN"
                                    if e_issn in src and e_isbn in src:
                                        h1 = src.index(e_issn)
                                        h2 = src.index(e_isbn)
                                        h2 = src[h2+26:].split('"')
                                        h2 = h2[0]
                                        issn = "ISSN:" + \
                                            src[h1+26:h1+35]+" "+"ISBN:"+h2
                                    elif e_issn in src:
                                        hh = src.index(e_issn)
                                        issn = "ISSN:"+src[hh+26:hh+35]

                                    elif e_isbn in src:
                                        hh = src.index(e_isbn)
                                        hh = src[hh+26:].split('"')
                                        issn = "ISBN:"+hh[0]
                                    print(issn, "****---------------------------")
                                    if publication_type == "JOURNAL":
                                        driver3.execute_script(
                                            "window.scrollTo(0, document.body.scrollHeight);")
                                        m = driver3.find_element(
                                            By.CLASS_NAME, "stats-document-abstract-publishedIn")

                                        a = m.find_element(By.TAG_NAME, 'a')
                                        driver3.get(a.get_attribute('href'))
                                        all_box = driver3.find_element(
                                            By.CLASS_NAME, "stats-jhp-impact-factor")
                                        if all_box != -1:
                                            impact_factor = all_box.find_element(By.CLASS_NAME,
                                                                                 "text-md-md-lh").text
                                        driver3.quit()

                                springer = "springer"
                                # SPRINGER ISBN+IMPACT FACTOR
                                if springer in publisher_name.lower():
                                    h = None
                                    try:
                                        h = driver.find_element(
                                            By.CLASS_NAME, "gsc_oci_title_link").get_attribute("href")
                                        print(h)
                                    except:
                                        try:
                                            sh = driver.find_element(
                                                By.CLASS_NAME, "gsc_oci_merged_snippet")
                                            sh = sh.find_element(
                                                By.TAG_NAME, "a").get_attribute("href")
                                            driv = webdriver.Chrome(
                                                options=options)
                                            driv.get(sh)
                                            h = driv.current_url
                                            driv.quit()
                                            print(h)
                                        except:
                                            print("NO LINK")
                                    if h != None:
                                        if "book" in h:
                                            print(
                                                "book-------------------------------------------")
                                            issn = "ISBN:"+h[39:]
                                            publication_type = "Book"
                                            print(issn, "----------------")
                                        elif "chapter" in h:
                                            print(
                                                "Conference--------------------------------------")
                                            h1 = h[42:].split("_")
                                            issn = "ISBN:"+h1[0]
                                            print(issn, "----------------")

                                        elif publication_type == "JOURNAL":
                                            driver3 = webdriver.Chrome(
                                                options=options)

                                            driver3.get(h)
                                            src = driver3.page_source
                                            e_issn = "Electronic ISSN"
                                            if e_issn in src:
                                                hh = src.index(e_issn)
                                                issn = "ISSN:"+src[hh:hh+35]
                                                print(issn, "****************")
                                            driver3.execute_script(
                                                "window.scrollTo(0, document.body.scrollHeight);")

                                            try:

                                                box = driver3.find_element(
                                                    By.CLASS_NAME, "app-journal-metrics")
                                                # print("hi1")
                                                tname = box.find_element(
                                                    By.TAG_NAME, "dt").text
                                                print(tname)
                                                if tname == "Impact factor":
                                                    impact_factor = box.find_element(
                                                        By.TAG_NAME, "dd").text
                                                    ind = impact_factor.index(
                                                        '(')
                                                    impact_factor = float(
                                                        impact_factor[:ind-1])
                                                    print(
                                                        " Springer impact factor-", impact_factor)
                                            except:
                                                print("No Impact Factor")
                                            driver3.quit()

                                if publication.objects.filter(faculty_id_id=faculty_id, title=title).count() == 0:

                                    db = publication(i, faculty_id_id=faculty_id, faculty_name=faculty_name, title=title, publication_type=publication_type, published_yr=published_yr,
                                                     publisher_name=publisher_name, citations=citations, h_index=h_index, Scopus=scopus, WebOfScience=webOfScience, impact_factor=impact_factor, issn_no=issn, name=name, authors=authors)
                                    db.save()

                                    i += 1
                                    cnt += 1
                                elif publication.objects.filter(faculty_id_id=faculty_id, title__icontains=title).values().count() != 0:
                                    obj1 = publication.objects.get(
                                        faculty_id_id=faculty_id, title__icontains=title)

                                    if (obj1.name != "-" and name != "-") and obj1.name == name:
                                        print("hi1")
                                        if obj1.published_yr == "-":
                                            print("hi2")
                                            obj1.published_yr = published_yr
                                        if obj1.issn_no == "--":
                                            obj1.issn_no = issn
                                        if obj1.publisher_name == "-":
                                            obj1.publisher_name = publisher_name
                                        obj1.save()
                                    elif obj1.name == "-" or name == "-":

                                        if obj1.issn_no == issn:
                                            if obj1.published_yr == "-":
                                                obj1.published_yr = published_yr
                                            if obj1.name == "-":
                                                obj1.name = name
                                            if obj1.publisher_name == "-":
                                                obj1.publisher_name = publisher_name
                                            obj1.save()
                                        else:
                                            v = publication(i, faculty_id_id=faculty_id, faculty_name=faculty_name, title=title,
                                                            publication_type=publication_type.upper(), name=name, publisher_name=publisher_name, published_yr=published_yr, issn_no=issn)
                                            i += 1
                                            v.save()
                                            up_cnt += 1
                                    else:
                                        v = publication(i, faculty_id_id=faculty_id, faculty_name=faculty_name, title=title,
                                                        publication_type=publication_type.upper(), name=name, publisher_name=publisher_name, published_yr=published_yr, issn_no=issn)
                                        i += 1
                                        v.save()
                                        up_cnt += 1

                                else:
                                    l = publication.objects.get(
                                        faculty_id_id=faculty_id, title=title)
                                    l.publication_type = publication_type
                                    l.publisher_name = publisher_name
                                    l.citations = citations
                                    l.h_index = h_index
                                    l.authors = authors
                                    l.impact_factor = impact_factor
                                    if l.WebOfScience == 0:
                                        l.WebOfScience = webOfScience
                                    if l.Scopus == 0:
                                        l.Scopus = scopus
                                    l.issn_no = issn
                                    l.save()
                                    ncnt += 1

                                driver.back()

                            messages.info(
                                request, "For faculty_id ={0} Number of Publications Uploaded={1}  Number of publications Not Uploaded={2}".format(faculty_id, cnt, ncnt))

                            driver.quit()
                            # driver4.quit()

                            # WEBOFSCIENCE
                            try:

                                author_id = author_ids.objects.get(
                                    faculty_id_id=faculty_id).author_id
                                print(author_id)
                                driver5 = webdriver.Chrome(
                                    chrome_options=options)
                                driver5.get(
                                    'https://www.webofscience.com/wos/')
                                uname = driver5.find_element(
                                    By.ID, "mat-input-0")
                                uname.clear()
                                uname.send_keys(
                                    "shivanid11@gnits.ac.in")
                                pwd = driver5.find_element(
                                    By.ID, "mat-input-1")
                                pwd.clear()
                                pwd.send_keys("@D.s.r123")
                                driver5.find_element(
                                    By.ID, "signIn-btn").click()
                                sleep(8)
                                driver5.find_element(
                                    By.CLASS_NAME, "dropdown").click()
                                sleep(6)
                                driver5.find_element(
                                    By.XPATH, "//*[@title='Author Identifiers']").click()
                                sleep(6)

                                print(author_id)
                                orcid = driver5.find_element(By.ID, "orcid")
                                print('hellooo')
                                print(author_id)
                                orcid.clear()
                                orcid.send_keys(author_id)
                                sleep(2)
                                v = driver5.find_element(
                                    By.CLASS_NAME, "wat-single-line-form-actions")

                                bns = v.find_elements(By.TAG_NAME, "button")
                                for e in bns:
                                    if e.get_attribute("type") == "submit":
                                        e.click()
                            except:
                                messages.info(
                                    request, "Their is no Author Id(WebOfScience) for {0}", format(faculty_id))

                            try:
                                driver5.execute_script(
                                    "window.scrollTo(0, document.body.scrollHeight);")
                                print("scrolled")
                                sleep(4)
                                driver5.find_element(
                                    By.CLASS_NAME, "mat-checkbox-inner-container").click()

                                sleep(4)
                                print("unchecked")
                                list_tit = driver5.find_elements(
                                    By.CLASS_NAME, "left-section")

                                for each_t in list_tit:
                                    tit = each_t.find_element(
                                        By.TAG_NAME, "a").text
                                    print("--------------",
                                          tit, "--------------")
                                    num = publication.objects.filter(
                                        faculty_id_id=faculty_id, title__iexact=tit).count()
                                    print(num, "****************")
                                    if num == 1:
                                        obj = publication.objects.get(
                                            faculty_id_id=faculty_id, title__iexact=tit)
                                        print(obj.WebOfScience)
                                        obj.WebOfScience = 1
                                        obj.save()
                                driver5.back()
                            except:
                                print("NO publications")
                    else:
                        messages.info(request, 'Please Choose Some File')
                        return render(request, 'home_a.html', context)

            return render(request, 'home_a.html', context)

        elif op1 != None:
            pub_res = pubResource
            dataset = Dataset()
            npub = request.FILES['myfile']
            if len(npub) == 0:
                messages.info(request, 'Wrong Format')
                return render(request, 'home_a.html', context)
            if not npub.name.endswith('xlsx'):
                print("ERROR!!")
                messages.info(request, 'Wrong Format')
                return render(request, 'home_a.html', context)
            imp_data = dataset.load(npub.read(), format='xlsx')

            up_cnt = 0
            notup_cnt = 0
            for data in imp_data:
                print(type(data))
                data = list(data)
                c = login_db.objects.filter(username=data[1]).values()
                if len(c) == 0:
                    messages.info(request, 'Enter Valid Faculty ID!!')
                else:
                    if data[4] == None:
                        data[4] = "-"
                    if data[5] == None:
                        data[5] = "-"
                    if data[6] == None:
                        data[6] = "-"
                    if data[8] == None:
                        data[8] = "--"
                    if publication.objects.filter(faculty_id_id=data[1], title__icontains=data[3]).values().count() == 0:

                        v = publication(i, faculty_id_id=data[1], faculty_name=data[2], title=data[3],
                                        publication_type=data[4].upper(), name=data[5], publisher_name=data[6], published_yr=data[7], issn_no=data[8])
                        i += 1
                        v.save()
                        up_cnt += 1
                    elif publication.objects.filter(faculty_id_id=data[1], title__icontains=data[3]).values().count() != 0:
                        obj1 = publication.objects.get(
                            faculty_id_id=data[1], title__icontains=data[3])

                        if (obj1.name != "-" and data[5] != "-") and obj1.name == data[5]:
                            print("hi1")
                            if obj1.published_yr == "-":
                                print("hi2")
                                obj1.published_yr = data[7]
                            if obj1.issn_no == "--":
                                obj1.issn_no = data[8]
                            if obj1.publisher_name == "-":
                                obj1.publisher_name = data[6]
                            obj1.save()
                        elif obj1.name == "-" or data[5] == "-":
                            if obj1.issn_no == data[8]:
                                if obj1.published_yr == "-":
                                    obj1.published_yr = data[7]
                                if obj1.name == "-":
                                    obj1.name = data[5]
                                if obj1.publisher_name == "-":
                                    obj1.publisher_name = data[6]
                                obj1.save()
                            else:
                                v = publication(i, faculty_id_id=data[1], faculty_name=data[2], title=data[3],
                                                publication_type=data[4].upper(), name=data[5], publisher_name=data[6], published_yr=data[7], issn_no=data[8])
                                i += 1
                                v.save()
                                up_cnt += 1
                        else:
                            v = publication(i, faculty_id_id=data[1], faculty_name=data[2], title=data[3],
                                            publication_type=data[4].upper(), name=data[5], publisher_name=data[6], published_yr=data[7], issn_no=data[8])
                            i += 1
                            v.save()
                            up_cnt += 1

                    else:

                        notup_cnt += 1

            messages.info(
                request, "Number of Publications Uploaded={0}  Number of Publications Not Uploaded={1}".format(up_cnt, notup_cnt))
        elif op2 != None:
            return redirect(updateP)
    return render(request, "home_a.html", context)


def updateP(request):
    op = request.POST.get('sb')

    if request.method == 'POST':
        if op == 'ADD PUBLICATIONS':
            return redirect(addP)
        elif(op == 'ADD OR REMOVE FACULTY'):
            return redirect(del_Fac)
        elif(op == 'ADD AUTHOR ID'):
            return redirect(auth_id)
        else:
            print("modify")
    else:
        print("Error!!")
    context = {'id': request.session.get('id')}
    return render(request, 'update.html', context)


def addP(request):
    id = request.session.get('id')
    if request.method == "POST" and request.POST.get('submit') != None:

        c = login_db.objects.filter(username=id).values()
        if len(c) == 0:
            messages.info(request, 'Enter Valid Faculty ID!!')
        faculty_name = request.POST.get("faculty_name")
        title = request.POST.get("title")
        authors = request.POST.get("authors")
        type = request.POST.get("type")
        name = request.POST.get("name")
        publisher_name = request.POST.get("publisher_name")
        published_yr = request.POST.get("published_yr")
        issn_no = request.POST.get("issn_no")
        citations = request.POST.get("citations")
        imp_fac = request.POST.get("impact_fac")
        h_ind = request.POST.get("h_index")
        scopus = request.POST.get("scopus")
        wos = request.POST.get("wos")
        global i
        if len(c) != 0:
            if publication.objects.filter(faculty_id_id=id, faculty_name=faculty_name, title=title).values().count() == 0:
                v = publication(i, id, faculty_name, title, authors, type, name, publisher_name,
                                published_yr, issn_no, imp_fac, h_ind, citations, scopus, wos)
                i += 1
                v.save()
                messages.info(request, 'Data Saved Successfully!!')
            else:
                messages.info(request, 'Data Already Exists!!')
    context = {'id': id}
    return render(request, "add_p.html", context)


def del_Fac(request):
    if request.method == "POST" and request.POST.get('dl') != None:
        faculty_id = request.POST.get("faculty_id")
        c = login_db.objects.filter(username=faculty_id).values()
        if len(c) == 0:
            messages.info(request, 'Enter Valid Faculty ID!!')
        else:
            c = login_db.objects.get(username=faculty_id)
            c.delete()
            messages.info(request, 'Faculty Removed Successfully!!')
    elif request.method == "POST" and request.POST.get('add') != None:
        uname = request.POST.get("uname")
        pwd = request.POST.get("pwd")
        c = login_db.objects.filter(username=uname).values()
        if len(c) == 1:
            messages.info(request, 'Already Exists!!')
        else:
            c = login_db(uname, pwd)
            c.save()
            messages.info(request, 'Faculty Added Successfully!!')
    context = {'id': request.session.get('id')}
    return render(request, "add_or_rem_fac.html", context)


def auth_id(request):
    id = request.session.get("id")
    context = {'id': id}
    if request.method == "POST" and request.POST.get('sb') != None:
        f_id = request.POST.get('faculty_id')
        a_id = request.POST.get('auth')
        if login_db.objects.filter(username=f_id).count() != 0:
            cnt = author_ids.objects.all().count()
            v = author_ids.objects.filter(
                faculty_id_id=f_id, author_id=a_id).count()
            print(v)
            if v == 0:
                obj = author_ids(cnt+1, f_id, a_id)
                obj.save()
                messages.info(request, "Author ID Saved!!")
            else:
                messages.info(request, "Author ID already present")
        else:
            messages.info(request, "Enter Valid Faculty Id")
    return render(request, "addAuthID.html", context)


def searchPub(request):
    list = publication.objects.all()
    myFilter = pubFilter(request.POST, queryset=list)
    list = myFilter.qs
    cnt = list.count()
    context = {'list': list, 'myFilter': myFilter,
               'id': request.session.get('id'), 'cnt': cnt}
    return render(request, "home_f.html", context)


def editP(request):
    print("HII")
    id = request.session.get("id")
    pb_id = request.session.get('pb_id')
    print(pb_id)
    li = publication.objects.get(id=pb_id)

    print(li.title, li.published_yr)
    context = {'id': id, 'li': li}
    if request.method == "POST" and request.POST.get('submit') != None:
        print("hey")

        faculty_name = request.POST.get("faculty_name")
        title = request.POST.get("title")
        authors = request.POST.get("authors")
        type = request.POST.get("type")
        name = request.POST.get("name")
        publisher_name = request.POST.get("publisher_name")
        published_yr = request.POST.get("published_yr")
        issn_no = request.POST.get("issn_no")
        print(issn_no)
        citations = request.POST.get("citations")
        imp_fac = request.POST.get("impact_fac")
        h_ind = request.POST.get("h_index")
        scopus = request.POST.get("scopus")
        wos = request.POST.get("wos")
        global i
        v = publication.objects.get(id=pb_id)
        v.faculty_name = faculty_name
        v.title = title
        v.authors = authors
        v.publication_type = type
        v.name = name
        v.publisher_name = publisher_name
        v.published_yr = published_yr
        v.issn_no = issn_no
        v.citations = citations
        v.impact_factor = imp_fac
        v.h_index = h_ind
        v.Scopus = scopus
        v.WebOfScience = wos
        v.save()
        del request.session['pb_id']
        messages.info(request, 'Data Updated Successfully!!')

    return render(request, "edit.html", context)


def myProfile(request):
    global i
    id = request.session.get("id")
    if request.method == "POST" and request.POST.get('pb') != None:
        pb_id = request.POST.get('pb')
        request.session['pb_id'] = pb_id
        print(request.session['pb_id'])
        return redirect(editP)
    if request.method == "POST" and request.POST.get('sb1') != None:
        return redirect(addP)
    if request.method == "POST" and request.POST.get('sb') != None:
        options = webdriver.ChromeOptions()
        options.add_experimental_option(
            'excludeSwitches', ['enable-logging'])

        driver = webdriver.Chrome(chrome_options=options)
        cnt = 0
        ncnt = 0
        f = urls.objects.filter(faculty_id_id=id).values('url')
        print(f)
        url = f[0].get('url')
        print(url)
        faculty_id = id
        driver.get(url)
        b = driver.find_element(By.ID, "gsc_bpf_more")
        driver.execute_script(
            "arguments[0].scrollIntoView(true);", b)
        b.click()
        sleep(10)
        j = 0
        while j < 6:
            j += 1

            driver.execute_script(
                "arguments[0].scrollIntoView(true);", b)
            b.click()

        faculty_name = driver.title[:-18]
        pub_titles = driver.find_elements(
            By.CLASS_NAME, "gsc_a_tr")
        '''
        driver4 = webdriver.Chrome(
            chrome_options=options)
        driver4.get(
            'https://id.elsevier.com/as/authorization.oauth2?platSite=SC%2Fscopus&ui_locales=en-US&scope=openid+profile+email+els_auth_info+els_analytics_info+urn%3Acom%3Aelsevier%3Aidp%3Apolicy%3Aproduct%3Aindv_identity&els_policy=idp_policy_indv_identity_plus&response_type=code&redirect_uri=https%3A%2F%2Fwww.scopus.com%2Fauthredirect.uri%3FtxGid%3Dcb06bc34b05b06755733b2fc4b0f32d0&state=userLogin%7CtxId%3D18D80740F186F5FA9FD5323B8C4BE0C4.i-04a4f73bb36ba75bc%3A9&authType=SINGLE_SIGN_IN&prompt=login&client_id=SCOPUS')
        sleep(5)
        email = driver4.find_element(
            By.ID, "bdd-email")
        email.clear()
        email.send_keys("shivanid11@gnits.ac.in")
        sleep(2)
        driver4.find_element(
            By.ID, "bdd-elsPrimaryBtn").click()
        pwd = driver4.find_element(
            By.ID, "bdd-password")
        pwd.clear()
        pwd.send_keys("@D.s.r123")
        sleep(2)

        driver4.find_element(
            By.ID, "bdd-elsPrimaryBtn").click()

        opt_val = "TITLE"

        optns = driver4.find_element(
            By.XPATH, "//select[option[@value='%s']]" % opt_val)
        select = Select(optns)
        select.select_by_value(opt_val)
        '''
        for each_tit in pub_titles:
            scopus = 0
            title_link = each_tit.find_element(
                By.CLASS_NAME, "gsc_a_at")
            title = title_link.text
            '''
            inp_box = driver4.find_element(
                By.CLASS_NAME, "flex-grow-1")
            inp_box.clear()
            inp_box.send_keys(title)
            submit_btn = driver4.find_element(
                By.CLASS_NAME, "DocumentSearchForm-module__7qtE8")
            submit_btn.submit()
            sleep(5)
            try:
                tit = driver4.find_element(
                    By.CLASS_NAME, "ddmDocTitle").text
                print(tit)
                if tit.lower() == title.lower():
                    scopus = 1
            except:
                scopus = 0
            print(title, "-", scopus)
            driver4.back()
            '''

            published_yr = "-"
            published_yr = each_tit.find_element(
                By.CLASS_NAME, "gsc_a_y").text
            a = each_tit.find_element(By.CLASS_NAME, "gsc_a_c")
            val = a.find_element(By.TAG_NAME, 'a')
            if val.text != '':
                citations = int(val.text)
            else:
                citations = 0
            try:
                h_row = driver.find_elements(
                    By.CLASS_NAME, "gsc_rsb_std")
                for x in range(3):
                    h_index = h_row[x].text
            except:
                h_index = 0
            title_link.click()
            details = driver.find_elements(
                By.CLASS_NAME, "gs_scl")
            val_fields = ["Book", "Journal", "Conference"]
            publisher_name = "-"
            publication_type = "-"
            name = "-"
            for each in details:
                field = each.find_element(
                    By.CLASS_NAME, "gsc_oci_field").text
                value = each.find_element(
                    By.CLASS_NAME, "gsc_oci_value").text
                if field == "Authors":
                    authors = value
                    print(authors)
                if field == "Publisher":
                    publisher_name = value
                if field in val_fields:
                    publication_type = field.upper()
                    name = value

            webOfScience = 0
            impact_factor = 0
            issn = "--"
            springer = "springer"

            if (publisher_name == "KICS" or publisher_name == "IEEE"):
                # print("each:", driver.current_url)
                try:
                    next_page = driver.find_element(
                        By.CLASS_NAME, "gsc_oci_title_link").get_attribute("href")
                    driver3 = webdriver.Chrome(
                        options=options)
                    driver3.get(next_page)

                    src = driver3.page_source
                    e_issn = "Electronic ISSN"
                    e_isbn = "Electronic ISBN"
                    if e_issn in src and e_isbn in src:
                        h1 = src.index(e_issn)
                        h2 = src.index(e_isbn)
                        h2 = src[h2+26:].split('"')
                        h2 = h2[0]
                        issn = "ISSN:"+src[h1+26:h1+35]+" "+"ISBN:"+h2
                    elif e_issn in src:
                        hh = src.index(e_issn)
                        issn = "ISSN:"+src[hh+26:hh+35]

                    elif e_isbn in src:
                        hh = src.index(e_isbn)
                        hh = src[hh+26:].split('"')
                        issn = "ISBN:"+hh[0]
                    print(issn, "****---------------------------")
                    if publication_type == "JOURNAL":
                        driver3.execute_script(
                            "window.scrollTo(0, document.body.scrollHeight);")
                        m = driver3.find_element(
                            By.CLASS_NAME, "stats-document-abstract-publishedIn")

                        a = m.find_element(By.TAG_NAME, 'a')
                        driver3.get(a.get_attribute('href'))
                        driver3.execute_script(
                            "window.scrollTo(0, document.body.scrollHeight);")
                        all_box = driver3.find_element(
                            By.CLASS_NAME, "stats-jhp-impact-factor")
                        if all_box != -1:
                            impact_factor = all_box.find_element(By.CLASS_NAME,
                                                                 "text-md-md-lh").text
                        else:
                            impact_factor = 0
                        print(impact_factor, "************")
                except StaleElementReferenceException:
                    print("NoSuchElementException")
                except NoSuchElementException:
                    print("NoSuchElementException")
                driver3.quit()
            if springer in publisher_name.lower():
                h = None
                try:
                    h = driver.find_element(
                        By.CLASS_NAME, "gsc_oci_title_link").get_attribute("href")
                    print(h)
                except:
                    try:
                        sh = driver.find_element(
                            By.CLASS_NAME, "gsc_oci_merged_snippet")
                        sh = sh.find_element(
                            By.TAG_NAME, "a").get_attribute("href")
                        driv = webdriver.Chrome(
                            options=options)
                        driv.get(sh)
                        h = driv.current_url
                        driv.quit()
                        print(h)
                    except:
                        print("NO LINK")
                if h != None:
                    if "book" in h:
                        print("book-------------------------------------------")

                        issn = "ISBN:"+h[39:]
                        publication_type = "Book"
                        print(issn, "----------------")
                    elif "chapter" in h:
                        print("Conference--------------------------------------")
                        h = h[42:].split("_")
                        h = h[0]
                        issn = "ISBN:"+h
                        print(issn, "----------------")

                    elif publication_type == "JOURNAL":

                        driver3 = webdriver.Chrome(
                            options=options)

                        driver3.get("https://www.springer.com/journal/10472")
                        src = driver3.page_source
                        e_issn = "Electronic ISSN"
                        if e_issn in src:
                            hh = src.index(e_issn)
                            issn = "ISSN:"+src[hh+73:hh+82]
                            print(issn, "****************")
                        driver3.execute_script(
                            "window.scrollTo(0, document.body.scrollHeight);")

                        try:
                            box = driver3.find_element(
                                By.CLASS_NAME, "app-journal-metrics")
                            # print("hi1")
                            tname = box.find_element(By.TAG_NAME, "dt").text
                            # print(tname)
                            if tname == "Impact factor":
                                impact_factor = box.find_element(
                                    By.TAG_NAME, "dd").text
                                ind = impact_factor.index('(')
                                impact_factor = float(impact_factor[:ind-1])
                                print("impact factor-", impact_factor)
                        except:
                            print("No Impact Factor")
                        driver3.quit()

            if publication.objects.filter(faculty_id_id=faculty_id, title=title).count() == 0:
                db = publication(i, faculty_id_id=faculty_id, faculty_name=faculty_name, title=title, publication_type=publication_type, published_yr=published_yr,
                                 publisher_name=publisher_name, citations=citations, h_index=h_index, Scopus=scopus, WebOfScience=webOfScience, impact_factor=impact_factor, issn_no=issn, name=name, authors=authors)
                db.save()

                i += 1
                cnt += 1
            elif publication.objects.filter(faculty_id_id=faculty_id, title__icontains=title).values().count() != 0:
                obj1 = publication.objects.get(
                    faculty_id_id=faculty_id, title__icontains=title)

                if (obj1.name != "-" and name != "-") and obj1.name == name:
                    print("hi1")
                    if obj1.published_yr == "-":
                        print("hi2")
                        obj1.published_yr = published_yr
                    if obj1.issn_no == "--":
                        obj1.issn_no = issn
                    if obj1.publisher_name == "-":
                        obj1.publisher_name = publisher_name
                    obj1.save()
                elif obj1.name == "-" or name == "-":

                    if obj1.issn_no == issn:
                        if obj1.published_yr == "-":
                            obj1.published_yr = published_yr
                        if obj1.name == "-":
                            obj1.name = name
                        if obj1.publisher_name == "-":
                            obj1.publisher_name = publisher_name
                        obj1.save()
                    else:
                        v = publication(i, faculty_id_id=faculty_id, faculty_name=faculty_name, title=title,
                                        publication_type=publication_type.upper(), name=name, publisher_name=publisher_name, published_yr=published_yr, issn_no=issn)
                        i += 1
                        v.save()
                        cnt += 1
                else:
                    v = publication(i, faculty_id_id=faculty_id, faculty_name=faculty_name, title=title,
                                    publication_type=publication_type.upper(), name=name, publisher_name=publisher_name, published_yr=published_yr, issn_no=issn)
                    i += 1
                    v.save()
                    cnt += 1
            else:
                l = publication.objects.get(
                    faculty_id_id=faculty_id, title=title)
                l.publication_type = publication_type
                l.publisher_name = publisher_name
                l.citations = citations
                l.h_index = h_index

                l.impact_factor = impact_factor
                if l.WebOfScience == 0:
                    l.WebOfScience = webOfScience
                if l.Scopus == 0:
                    l.Scopus = scopus
                l.issn_no = issn
                l.save()
                ncnt += 1

            driver.back()

        messages.info(
            request, " Number of Publications Added={0} ".format(cnt))

        driver.quit()
        # driver4.quit()

        # WEBOFSCIENCE
        try:
            author_id = author_ids.objects.get(faculty_id_id=id).author_id
            driver5 = webdriver.Chrome(
                chrome_options=options)
            driver5.get(
                'https://www.webofscience.com/wos/')
            uname = driver5.find_element(
                By.ID, "mat-input-0")
            uname.clear()
            uname.send_keys(
                "shivanid11@gnits.ac.in")
            pwd = driver5.find_element(
                By.ID, "mat-input-1")
            pwd.clear()
            pwd.send_keys("@D.s.r123")
            driver5.find_element(
                By.ID, "signIn-btn").click()
            sleep(5)
            # print("submitted===================")
            driver5.find_element(
                By.CLASS_NAME, "dropdown").click()
            #print("DRopdown clicked==================================")
            sleep(5)
            driver5.find_element(
                By.XPATH, "//*[@title='Author Identifiers']").click()
            sleep(5)

            print(author_id)
            orcid = driver5.find_element(By.ID, "orcid")
            orcid.clear()
            orcid.send_keys(author_id)
            sleep(2)
            v = driver5.find_element(
                By.CLASS_NAME, "wat-single-line-form-actions")

            bns = v.find_elements(By.TAG_NAME, "button")
            for e in bns:
                if e.get_attribute("type") == "submit":
                    e.click()
            # print("HEYY======================")
        except:
            # print("hey2==================")
            messages.info(request, "There is no Author Id(WebOfScience)")
        try:
            driver5.execute_script(
                "window.scrollTo(0, document.body.scrollHeight);")
            print("scrolled")
            sleep(5)
            driver5.find_element(
                By.CLASS_NAME, "mat-checkbox-inner-container").click()
            print("unchecked")
            sleep(5)
            list_tit = driver5.find_elements(By.CLASS_NAME, "left-section")
            print(list_tit)
            sleep(5)
            for each_t in list_tit:
                tit = each_t.find_element(By.TAG_NAME, "a").text
                print(tit)
                num = publication.objects.filter(
                    faculty_id_id=id, title__iexact=tit).count()
                print(num, "****************")
                if num == 1:
                    obj = publication.objects.get(
                        faculty_id_id=id, title__iexact=tit)
                    print(obj.WebOfScience)
                    obj.WebOfScience = 1
                    obj.save()
            driver5.back()
        except:
            print("NO publications")
    # Download
    if request.method == "POST" and request.POST.get('btn') != None:
        faculty_name = publication.objects.filter(faculty_id_id=id)
        print(faculty_name)
        faculty_name = faculty_name[0].faculty_name
        faculty_name = faculty_name[1:-2]

        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="MyPublications.csv"'
        writer = csv.writer(response)
        writer.writerow(['PUBLICATION DETAILS'])
        writer.writerows(
            [['Faculty Id :', id]])
        writer.writerow(['Faculty Name', 'Title', 'Authors', 'Publication Type', 'Name', 'Publisher Name',
                         'Published Year', 'ISSN NO', 'H-ndex', 'Impact Factor', 'Scopus', 'WebOfScience', 'Citations'])
        list1 = publication.objects.filter(faculty_id_id=id).values_list('title', 'authors', 'publication_type', 'name', 'publisher_name',
                                                                         'published_yr', 'issn_no', 'h_index', 'impact_factor', 'Scopus', 'WebOfScience', 'citations')
        # print(list1)
        for e in list1:
            e = list(e)
            e = [faculty_name]+e
            print(e)
            writer.writerow(e)
        return response

    li = publication.objects.filter(
        faculty_id_id=id).order_by('-published_yr').values()
    cnt = li.count()
    if cnt == 0:
        # messages.info(request, "No Publications!!")
        context = {'empty': False,  'id': id}
        return render(request, "profile.html", context)
    cit = sum(li.values_list('citations', flat=True))
    noj = publication.objects.filter(
        faculty_id_id=id, publication_type="JOURNAL").count()
    noc = publication.objects.filter(
        faculty_id_id=id, publication_type="CONFERENCE").count()
    nob = publication.objects.filter(
        faculty_id_id=id, publication_type="BOOK").count()
    sc = publication.objects.filter(
        faculty_id_id=id, Scopus=1).count()
    wos = publication.objects.filter(
        faculty_id_id=id, WebOfScience=1).count()
    h_val = publication.objects.filter(faculty_id_id=id).first()
    h_ind = h_val.h_index
    faculty_name = h_val.faculty_name
    print("----------------------------- Total publications :", cnt, "------------")
    imp_fac = max(li.values_list('impact_factor', flat=True))
    context = {'list': li, 'id': id, 'cnt': cnt, 'cit': cit,
               'sc': sc, 'wos': wos, 'h_ind': h_ind, 'imp_fac': imp_fac, 'empty': True, 'Fname': faculty_name, 'noj': noj, 'noc': noc, 'nob': nob}

    return render(request, "profile.html", context)


def searchStu(request):
    list = publication.objects.all()
    myFilter = pubFilter(request.POST, queryset=list)
    list = myFilter.qs
    cnt = list.count()
    print(cnt)
    id = request.session.get("id")
    context = {'list': list, 'myFilter': myFilter,
               'id': id, 'cnt': cnt}
    return render(request, "home_s.html", context)


def searchAdm(request):
    list = publication.objects.all()
    myFilter = pubFilter(request.POST, queryset=list)
    list = myFilter.qs
    cnt = list.count()
    id = request.session.get("id")
    context = {'list': list, 'myFilter': myFilter, 'id': id, 'cnt': cnt}
    return render(request, "pub_a.html", context)


def rpForm(request):
    id = request.session.get("id")
    c = {'id': id, 'empty': False}
    if request.method == "POST" and request.POST.get('sb') != None:
        fid = request.POST.get('fid')

        list = publication.objects.filter(
            faculty_id_id=fid).order_by('-published_yr').values()

        cnt = list.count()
        print(cnt)
        if cnt == 0:
            messages.info(request, 'Enter Faculty Id')
            return render(request, "researchProfile.html", c)
        cit = sum(list.values_list('citations', flat=True))
        noj = publication.objects.filter(
            faculty_id_id=fid, publication_type="JOURNAL").count()
        noc = publication.objects.filter(
            faculty_id_id=fid, publication_type="CONFERENCE").count()
        nob = publication.objects.filter(
            faculty_id_id=fid, publication_type="BOOK").count()
        sc = publication.objects.filter(
            faculty_id_id=fid, Scopus=1).count()
        wos = publication.objects.filter(
            faculty_id_id=fid, WebOfScience=1).count()
        h = publication.objects.filter(faculty_id_id=fid).first()
        h_ind = h.h_index
        faculty_name = h.faculty_name
        imp_fac = max(list.values_list('impact_factor', flat=True))
        context = {'list': list, 'id': id, 'cnt': cnt, 'cit': cit,
                   'sc': sc, 'wos': wos, 'h_ind': h_ind, 'imp_fac': imp_fac, 'Fname': faculty_name, 'noj': noj, 'noc': noc, 'nob': nob, 'empty': True}
        return render(request, "researchProfile.html", context)

    return render(request, "researchProfile.html", c)


def rpForm_adm(request):
    id = request.session.get("id")
    c = {'id': id, 'empty': False}
    if request.method == "POST" and request.POST.get('sb') != None:
        fid = request.POST.get('fid')

        list = publication.objects.filter(
            faculty_id_id=fid).order_by('-published_yr').values()
        gp = publication.objects.values('published_yr').annotate(
            dcount=Count('published_yr')).order_by('published_yr')
        print(gp)
        cnt = list.count()
        print(cnt)
        if cnt == 0:
            messages.info(request, 'Enter Faculty Id')
            return render(request, "summary_adm.html", c)
        cit = sum(list.values_list('citations', flat=True))
        noj = publication.objects.filter(
            faculty_id_id=fid, publication_type="JOURNAL").count()
        noc = publication.objects.filter(
            faculty_id_id=fid, publication_type="CONFERENCE").count()
        nob = publication.objects.filter(
            faculty_id_id=fid, publication_type="BOOK").count()
        sc = publication.objects.filter(
            faculty_id_id=fid, Scopus=1).count()
        wos = publication.objects.filter(
            faculty_id=fid, WebOfScience=1).count()
        h = publication.objects.filter(faculty_id_id=fid).first()
        h_ind = h.h_index

        faculty_name = h.faculty_name
        imp_fac = max(list.values_list('impact_factor', flat=True))
        context = {'list': list, 'id': id, 'cnt': cnt, 'cit': cit,
                   'sc': sc, 'wos': wos, 'h_ind': h_ind, 'imp_fac': imp_fac, 'Fname': faculty_name, 'noj': noj, 'noc': noc, 'nob': nob, 'empty': True}
        return render(request, "summary_adm.html", context)

    return render(request, "summary_adm.html", c)


def summaryF(request):
    id = request.session.get("id")
    c = {'id': id, 'empty': False}
    if request.method == "POST" and request.POST.get('sb') != None:
        fid = request.POST.get('fid')
        list = publication.objects.filter(
            faculty_id_id=fid).order_by('-published_yr').values()

        cnt = list.count()
        print(cnt)
        if cnt == 0:
            messages.info(request, 'Enter Faculty Id')
            return render(request, "summary_adm.html", c)
        cit = sum(list.values_list('citations', flat=True))
        noj = publication.objects.filter(
            faculty_id_id=fid, publication_type="JOURNAL").count()
        noc = publication.objects.filter(
            faculty_id_id=fid, publication_type="CONFERENCE").count()
        nob = publication.objects.filter(
            faculty_id_id=fid, publication_type="BOOK").count()
        sc = publication.objects.filter(
            faculty_id_id=fid, Scopus=1).count()
        wos = publication.objects.filter(
            faculty_id=fid, WebOfScience=1).count()
        h = publication.objects.filter(faculty_id_id=fid).first()
        h_ind = h.h_index
        faculty_name = h.faculty_name
        imp_fac = max(list.values_list('impact_factor', flat=True))
        context = {'list': list, 'id': id, 'cnt': cnt, 'cit': cit,
                   'sc': sc, 'wos': wos, 'h_ind': h_ind, 'imp_fac': imp_fac, 'Fname': faculty_name, 'noj': noj, 'noc': noc, 'nob': nob, 'empty': True}
        return render(request, "summaryFac.html", context)

    return render(request, "summaryFac.html", c)


def changePwd(request):
    id = request.session.get("id")
    context = {'id': id}
    print("heyyy")
    if request.method == "POST" and request.POST.get('sb') != None:
        npwd = request.POST.get("p1")
        cpwd = request.POST.get("p2")
        print(npwd)
        print(cpwd)
        if npwd == cpwd:
            obj = login_db.objects.get(username=id)
            obj.password = npwd
            obj.save()
            messages.info(request, "Password Changed Successfully")
        else:
            messages.info(
                request, "Confirm password is not matching with New Password")
    return render(request, "Change_pwd.html", context)
